"use client";
import { useContext, type CSSProperties, type ReactNode } from "react";
import { VisualContext, useVisualCopy } from "@/lib/visual";
import {
  defaultPhotography,
  defaultPhotoFrame,
  photoRoles,
} from "@/lib/photography";
export function ProductPhoto({
  imageKey,
  className,
  children,
  frameOverride,
  settingsOverride,
}: {
  imageKey: string;
  className: string;
  children: ReactNode;
  frameOverride?: import("@/lib/photography").PhotoFrame;
  settingsOverride?: import("@/lib/photography").Photography;
}) {
  const design = useContext(VisualContext),
    settings = settingsOverride || design.photography || defaultPhotography,
    frame =
      frameOverride || design.photoFrames?.[imageKey] || defaultPhotoFrame;
  return (
    <div
      className={className}
      data-photography
      data-photo-role={frame.role}
      style={
        {
          "--photo-ratio":
            settings.aspect === "portrait"
              ? "4 / 5"
              : settings.aspect === "landscape"
                ? "4 / 3"
                : "1 / 1",
          "--photo-background":
            settings.background === "light"
              ? "#e8e8e3"
              : settings.background === "original"
                ? "transparent"
                : "#141414",
          "--photo-fit": settings.fit,
          "--photo-scale": ((settings.scale / 100) * frame.scale) / 100,
          "--photo-x": frame.x + "%",
          "--photo-y": frame.y + "%",
          "--photo-shift-x": (frame.x - 50) / 2 + "%",
          "--photo-shift-y": (frame.y - 50) / 2 + "%",
        } as CSSProperties
      }
    >
      {children}
    </div>
  );
}

export function PhotoCaption({ imageKey }: { imageKey: string }) {
  const copy = useVisualCopy("tr");
  const design = useContext(VisualContext),
    frame = design.photoFrames?.[imageKey];
  return frame ? (
    <span
      className="photo-caption"
      data-visual-text={"slot:photo.caption." + frame.role}
    >
      {copy("photo.caption." + frame.role, photoRoles[frame.role])}
    </span>
  ) : null;
}
